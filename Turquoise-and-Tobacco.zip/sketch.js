/**
 * Title: "Turquoise and Tobacco"
 * Author: Aliston Ma
 * Date: 8/11/2025
 * AI Usage Statement: CHATGPT
 * Link to AI Transcript: https://chatgpt.com/share/6899b97e-891c-8008-b821-f2d9cb58e4b4
 *
 * Story:
 *  - Scene opens with the character asleep in bed (dim room, soft Z's).
 *  - Click the character in bed to wake him up.
 *  - After waking, your original interactive scene resumes (camera, moods, smoke, etc.).
 */

 let gameState = "sleep";        // "sleep" | "awake"
 let wakeFade = 0;               // fade-in overlay when waking up
 
 let afterImage = null;
 let afterAlpha = 0;
 let flashAlpha = 0;
 
 let mood = "calm";
 
 let cig;
 let cigSmoke = [];
 let cigEmitTimer = 0;
 
 let palettes = {
   calm:    { sun: "#FFF5BA" },
   furious: { sun: "#FFD700" }
 };
 
 // Walking & person state (awake mode)
 let stepPhase = 0;
 let lastMouseX = 0;
 let personPos = { x: 0, y: 0 };
 let personHand = { x: 0, y: 0 };
 
 // Camera object (on the desk by default)
 let camObj = {
   x: 0, y: 0, w: 34, h: 20,
   held: false,
   homeX: 0, homeY: 0
 };
 
 // Sleep-scene geometry cache
 let bedRect = { x: 0, y: 0, w: 0, h: 0, pillow: {x:0,y:0,w:0,h:0} };
 
 function setup() {
   createCanvas(windowWidth, windowHeight);
   noStroke();
   layoutScene();
 }
 
 function windowResized() {
   resizeCanvas(windowWidth, windowHeight);
   layoutScene();
 }
 
 function layoutScene() {
   cig = {
     x: width * 0.66,
     y: height * 0.74 - 6,
     angle: -PI / 28,
     len: 78,
     thick: 10,
     emberX: 0,
     emberY: 0
   };
 
   const deskX = width * 0.6;
   const deskY = height * 0.74;
   camObj.homeX = deskX + 28;
   camObj.homeY = deskY - 8;
   if (!camObj.held) {
     camObj.x = camObj.homeX;
     camObj.y = camObj.homeY;
   }
 
   bedRect.x = width * 0.1;
   bedRect.y = height * 0.6;
   bedRect.w = width * 0.45;
   bedRect.h = height * 0.16;
   bedRect.pillow = {
     x: width * 0.12,
     y: height * 0.58,
     w: width * 0.15,
     h: height * 0.06
   };
 }
 
 function draw() {
   if (gameState === "sleep") {
     drawSleepScene();
     return;
   }
 
   drawSunsetGradientAndSun();
   const win = drawRoom();
 
   drawPerson();
   drawCamera();
 
   const cup = { x: width * 0.75, y: height * 0.85, r: 42 };
   drawMatcha(cup);
   drawCigarette(cig);
   emitCigSmoke();
   updateDrawCigSmoke();
 
   drawGrain(220, 18);
 
   if (afterImage && afterAlpha > 0) {
     push();
     tint(255, afterAlpha);
     image(afterImage, 0, 0);
     pop();
     afterAlpha -= 1.5;
   }
   if (flashAlpha > 0) {
     fill(255, flashAlpha);
     rect(0, 0, width, height);
     flashAlpha -= 15;
   }
 
   fill(255, 210);
   textSize(14);
   textAlign(LEFT, TOP);
   text(`Mood: ${mood}  (press C/F)`, 10, 10);
 
   if (!camObj.held && isNearCamera() && overCamera(mouseX, mouseY)) {
     drawHint("Click to pick up", camObj.x, camObj.y - 24);
   } else if (!camObj.held && isNearCamera()) {
     drawHint("Move cursor closer & click camera", camObj.x, camObj.y - 24);
   } else if (camObj.held) {
     drawHint("Click to snap  •  Press D to drop", personHand.x + 20, personHand.y - 40);
   }
 
   const dx = mouseX - lastMouseX;
   stepPhase += constrain(abs(dx) * 0.02, 0, 0.3);
   lastMouseX = mouseX;
 
   if (wakeFade > 0) {
     fill(0, wakeFade);
     rect(0, 0, width, height);
     wakeFade -= 6;
   }
 }
 
 /* -------------------- Sleep Scene -------------------- */
 
 function drawSleepScene() {
   drawSleepGradientAndMoon();
   drawRoomSleeping();
 
   drawSleepingPerson(); // on the bed
 
   drawGrain(160, 14);
 
   fill(255, 230);
   textSize(14);
   textAlign(CENTER, BOTTOM);
   text("Click the sleeping figure to wake up", width / 2, height - 24);
 
   // A soft dim vignette to sell the “night”
   noStroke();
   for (let i = 0; i < 5; i++) {
     const a = map(i, 0, 4, 40, 130);
     stroke(0, a);
     noFill();
     rect(20 + i * 6, 20 + i * 6, width - 40 - i * 12, height - 40 - i * 12, 18);
   }
 }
 
 function drawSleepGradientAndMoon() {
   const cTop = color(10, 20, 35);
   const cBottom = color(30, 35, 60);
   for (let y = 0; y < height; y++) {
     const inter = y / height;
     const c = lerpColor(cTop, cBottom, inter);
     stroke(c);
     line(0, y, width, y);
   }
   const moonX = width * 0.72;
   const moonY = height * 0.22;
   fill(240, 240, 255, 180);
   circle(moonX, moonY, 80);
 }
 
 function drawRoomSleeping() {
   noStroke();
   fill(0, 35);
   rect(0, height * 0.78, width, height * 0.22);
 
   fill(40, 120, 120, 140);
   rect(bedRect.x, bedRect.y, bedRect.w, bedRect.h, 14);
 
   fill(210, 160, 170, 180);
   rect(bedRect.pillow.x, bedRect.pillow.y, bedRect.pillow.w, bedRect.pillow.h, 10);
 
   fill(40, 40, 50, 160);
   rect(width * 0.6, height * 0.74, width * 0.25, height * 0.05, 8);
 
   const win = { x: width * 0.55, y: height * 0.18, w: width * 0.35, h: height * 0.3 };
   fill(220, 230, 255, 40);
   rect(win.x, win.y, win.w, win.h, 10);
 
   push();
   drawingContext.save();
   drawingContext.beginPath();
   drawingContext.roundRect(win.x, win.y, win.w, win.h, 10);
   drawingContext.clip();
   noStroke();
   fill(255, 255, 255, 18);
   let rx = win.x + win.w * 0.1;
   for (let i = 0; i < 3; i++) {
     quad(rx + i * 18, win.y + 8,
          rx + i * 18 + 6, win.y + 18,
          rx + i * 18 + win.w * 0.2, win.y + win.h - 12,
          rx + i * 18 + win.w * 0.2 + 6, win.y + win.h - 2);
   }
   drawingContext.restore();
   pop();
 
   drawTriangularCurtains(win);
 }
 
 function drawSleepingPerson() {
   const px = bedRect.x + bedRect.w * 0.28;
   const py = bedRect.y + bedRect.h * 0.48;
 
   const breathe = sin(frameCount * 0.03) * 2;
 
   noStroke();
   fill(0, 40);
   ellipse(px + 20, py + 34, 36, 10);
 
   const skin = color(245, 220, 200);
   const shirt = color(70, 120, 160);
 
   fill(shirt);
   rect(px - 12, py - 6 + breathe, 24, 20, 6);
 
   fill(skin);
   ellipse(px - 22, py - 16, 18, 20); // head on pillow
 
   fill(30, 30, 40, 220);
   rect(px - 8, py - 10 + breathe, 6, 16, 3);
   rect(px + 2, py - 10 + breathe, 6, 16, 3);
 
   fill(30);
   rect(px - 26, py - 16, 8, 2, 1);
 
   const zBaseX = px - 38;
   const zBaseY = py - 38;
   drawZ(zBaseX, zBaseY, 10, 150);
   drawZ(zBaseX - 14, zBaseY - 16, 14, 120);
   drawZ(zBaseX - 28, zBaseY - 32, 18, 90);
 }
 
 function drawZ(x, y, s, a) {
   push();
   translate(x, y + sin(frameCount * 0.02 + x * 0.1) * 2);
   fill(255, a);
   noStroke();
   textAlign(CENTER, CENTER);
   textSize(s);
   text("Z", 0, 0);
   pop();
 }
 
 function isClickOnSleeper(mx, my) {
   const px = bedRect.x + bedRect.w * 0.28;
   const py = bedRect.y + bedRect.h * 0.48;
   const hx = px - 22;
   const hy = py - 16;
   return dist(mx, my, hx, hy) < 28 ||
          (mx > bedRect.x && mx < bedRect.x + bedRect.w &&
           my > bedRect.y && my < bedRect.y + bedRect.h);
 }
 
 /* -------------------- Input -------------------- */
 
 function mousePressed() {
   if (gameState === "sleep") {
     if (isClickOnSleeper(mouseX, mouseY)) {
       gameState = "awake";
       wakeFade = 180;
     }
     return;
   }
 
   if (camObj.held) {
     flashAlpha = 255;
     afterImage = get();
     afterAlpha = 140;
     return;
   }
 
   if (!camObj.held && overCamera(mouseX, mouseY) && isNearCamera()) {
     camObj.held = true;
   }
 }
 
 function keyPressed() {
   if (gameState === "sleep") return;
 
   if (key === 'F' || key === 'f') mood = "furious";
   if (key === 'C' || key === 'c') mood = "calm";
   if ((key === 'D' || key === 'd') && camObj.held) {
     camObj.held = false;
     camObj.x = camObj.homeX;
     camObj.y = camObj.homeY;
   }
 }
 
 /* -------------------- Shared Scene Pieces -------------------- */
 
 function drawSunsetGradientAndSun() {
   let cTop, cBottom, sunCol;
   if (mood === "calm") {
     cTop = color(64, 224, 208);
     cBottom = color(255, 182, 193);
     sunCol = color(palettes.calm.sun);
   } else {
     cTop = color(255, 140, 0);
     cBottom = color(255, 0, 0);
     sunCol = color(palettes.furious.sun);
   }
 
   noStroke();
   for (let y = 0; y < height; y++) {
     const inter = y / height;
     const c = lerpColor(cTop, cBottom, inter);
     fill(c);
     rect(0, y, width, 1);
   }
 
   const sunX = width * 0.725;
   const sunY = height * 0.31;
   const sunR = (mood === "calm") ? 110 : 95;
   fill(red(sunCol), green(sunCol), blue(sunCol), 170);
   circle(sunX, sunY, sunR);
 }
 
 function drawRoom() {
   noStroke();
   fill(0, 35);
   rect(0, height * 0.78, width, height * 0.22);
 
   fill(64, 224, 208, 210);
   rect(bedRect.x, bedRect.y, bedRect.w, bedRect.h, 14);
 
   fill(255, 182, 193, 230);
   rect(bedRect.pillow.x, bedRect.pillow.y, bedRect.pillow.w, bedRect.pillow.h, 10);
 
   fill(50, 50, 60, 180);
   rect(width * 0.6, height * 0.74, width * 0.25, height * 0.05, 8);
 
   const win = { x: width * 0.55, y: height * 0.18, w: width * 0.35, h: height * 0.3 };
   fill(230, 230, 240, 90);
   rect(win.x, win.y, win.w, win.h, 10);
 
   drawTriangularCurtains(win);
 
   push();
   drawingContext.save();
   drawingContext.beginPath();
   drawingContext.roundRect(win.x, win.y, win.w, win.h, 10);
   drawingContext.clip();
   noStroke();
   fill(255, 255, 255, 24);
   let rx = win.x + win.w * 0.1;
   for (let i = 0; i < 3; i++) {
     quad(rx + i * 18, win.y + 8,
          rx + i * 18 + 6, win.y + 18,
          rx + i * 18 + win.w * 0.2, win.y + win.h - 12,
          rx + i * 18 + win.w * 0.2 + 6, win.y + win.h - 2);
   }
   drawingContext.restore();
   pop();
 
   drawTriangularCurtains(win);
 
   drawAshtray(width * 0.685, height * 0.74 - 4, 36, 10);
 
   return win;
 }
 
 function drawTriangularCurtains(win) {
   stroke(60, 60, 70, 200);
   strokeWeight(4);
   line(win.x - 16, win.y - 8, win.x + win.w + 16, win.y - 8);
   noStroke();
 
   const col = (mood === "calm")
     ? color(255, 255, 255, 85)
     : color(255, 120, 90, 90);
 
   const swayAmp = (mood === "calm") ? 6 : 10;
   const swaySpeed = (mood === "calm") ? 0.02 : 0.04;
   const sway = sin(frameCount * swaySpeed) * swayAmp;
 
   const cx = win.x + win.w * 0.5;
   const gap = 8;
 
   fill(col);
   beginShape();
   vertex(win.x, win.y);
   vertex(win.x + win.w * 0.5, win.y);
   vertex(cx - gap - 2, win.y + win.h + 8 + sway);
   vertex(win.x, win.y + win.h + 8);
   endShape(CLOSE);
 
   fill(col);
   beginShape();
   vertex(win.x + win.w * 0.5, win.y);
   vertex(win.x + win.w, win.y);
   vertex(win.x + win.w, win.y + win.h + 8);
   vertex(cx + gap + 2, win.y + win.h + 8 + sway);
   endShape(CLOSE);
 
   fill(255, 255, 255, 60);
   rect(win.x + win.w * 0.21, win.y + win.h * 0.48, 18, 5, 3);
   rect(win.x + win.w * 0.71, win.y + win.h * 0.48, 18, 5, 3);
 
   stroke(255, 255, 255, 28);
   strokeWeight(1);
   for (let i = 1; i <= 3; i++) {
     let px = lerp(win.x, win.x + win.w * 0.5, i / 4);
     line(px, win.y + 6, lerp(px, cx - gap - 2, 0.15), win.y + win.h + 6);
   }
   for (let i = 1; i <= 3; i++) {
     let px = lerp(win.x + win.w * 0.5, win.x + win.w, i / 4);
     line(px, win.y + 6, lerp(px, cx + gap + 2, 0.15), win.y + win.h + 6);
   }
   noStroke();
 }
 
 function drawAshtray(cx, cy, w, h) {
   fill(0, 40);
   ellipse(cx, cy + 6, w * 1.1, h * 0.9);
   fill(210, 210, 220, 220);
   ellipse(cx, cy, w, h);
   fill(180, 180, 190, 200);
   ellipse(cx, cy, w * 0.72, h * 0.55);
   fill(160, 160, 170, 220);
   arc(cx - w * 0.32, cy, 10, 8, PI * 0.8, PI * 1.2, OPEN);
 }
 
 /* ---------------------- Awake Person ---------------------- */
 
 function drawPerson() {
   const floorY = height * 0.78;
   const minX = width * 0.08;
   const maxX = width * 0.92;
 
   const px = constrain(mouseX, minX, maxX);
   const crouch = map(mouseY, 0, height, 0, 10);
   const py = floorY - 42 + crouch;
 
   personPos.x = px;
   personPos.y = py;
 
   push();
   translate(px, py);
 
   const bob = sin(stepPhase) * ((mood === "calm") ? 2.5 : 4);
 
   const shirt = (mood === "calm") ? color(80, 160, 200) : color(200, 80, 80);
   const pants = (mood === "calm") ? color(40, 90, 130)  : color(90, 30, 30);
   const skin  = color(245, 220, 200);
 
   noStroke();
   fill(0, 40);
   ellipse(0, 44, 36, 10);
 
   fill(pants);
   rect(-8, 10 + bob, 6, 26, 3);
   rect( 2, 10 - bob, 6, 26, 3);
 
   fill(30, 30, 40);
   rect(-9, 34 + bob, 10, 4, 2);
   rect( 1, 34 - bob, 10, 4, 2);
 
   fill(shirt);
   rect(-11, -10, 22, 22, 6);
 
   fill(skin);
   rect(-16, -10 + (-bob), 5, 18, 3);
   rect( 11, -10 + ( bob), 5, 18, 3);
 
   fill(skin);
   ellipse(0, -24, 18, 20);
 
   fill(30);
   const eyeDY = (mood === "calm") ? 0 : 1;
   circle(-4, -26 + eyeDY, 2.2);
   circle( 4, -26 + eyeDY, 2.2);
   stroke(30);
   strokeWeight(1);
   line(-3, -21 + eyeDY, 3, -21 + eyeDY);
   noStroke();
 
   const handLocalX = 11 + 5;
   const handLocalY = -10 + (sin(stepCount()) * ((mood === "calm") ? 2.5 : 4)) + 18;
   personHand.x = px + handLocalX;
   personHand.y = py + handLocalY;
 
   pop();
 }
 function stepCount() { return stepPhase; }
 
 /* ------------------------- Camera ------------------------- */
 
 function drawCamera() {
   if (camObj.held) {
     drawCameraSprite(personHand.x, personHand.y, true);
   } else {
     drawCameraSprite(camObj.x, camObj.y, false);
     if (overCamera(mouseX, mouseY)) {
       noFill();
       stroke(255, 230);
       rect(camObj.x - camObj.w/2 - 3, camObj.y - camObj.h/2 - 3, camObj.w + 6, camObj.h + 6, 4);
       noStroke();
     }
   }
 }
 
 function drawCameraSprite(cx, cy, held) {
   push();
   translate(cx, cy);
 
   if (!held) {
     fill(0, 45);
     ellipse(0, 10, camObj.w * 0.9, 6);
   }
 
   fill(35, 40, 50);
   rect(-camObj.w/2, -camObj.h/2, camObj.w, camObj.h, 4);
 
   fill(45, 50, 60);
   rect(-camObj.w/2 + 4, -camObj.h/2 - 6, camObj.w - 8, 6, 2);
 
   fill(20, 22, 25);
   ellipse(camObj.w*0.16, 0, camObj.h*0.9, camObj.h*0.9);
   fill(90, 140, 200, 180);
   ellipse(camObj.w*0.16, 0, camObj.h*0.5, camObj.h*0.5);
 
   fill(200, 70, 70);
   rect(-camObj.w/2 + 6, -camObj.h/2 - 5, 6, 4, 1);
 
   if (held) {
     stroke(60, 60, 70, 180);
     strokeWeight(2);
     noFill();
     arc(-camObj.w/2, -camObj.h/2, 24, 18, PI, TWO_PI);
     noStroke();
   }
 
   pop();
 }
 
 function overCamera(mx, my) {
   if (camObj.held) return false;
   return (
     mx >= camObj.x - camObj.w/2 &&
     mx <= camObj.x + camObj.w/2 &&
     my >= camObj.y - camObj.h/2 &&
     my <= camObj.y + camObj.h/2
   );
 }
 
 function isNearCamera() {
   if (camObj.held) return true;
   const d = dist(personPos.x, personPos.y, camObj.x, camObj.y);
   return d < 80;
 }
 
 /* --------------------- Matcha & Cigarette ---------------------- */
 
 function drawMatcha(cup) {
   fill(230, 230, 240, 160);
   ellipse(cup.x, cup.y + 16, 90, 24);
 
   fill(235, 235, 245, 210);
   ellipse(cup.x, cup.y, 86, 58);
 
   push();
   translate(cup.x, cup.y);
   fill(150, 200, 150, 230);
 
   beginShape();
   let rippleSpeed  = (mood === "calm") ? 0.04 : 0.08;
   let rippleAmp    = (mood === "calm") ? 1.8  : 3.0;
   let rippleDetail = 50;
 
   for (let angle = 0; angle < TWO_PI; angle += TWO_PI / rippleDetail) {
     let baseX = cos(angle) * 36;
     let baseY = sin(angle) * 11;
     let ripple = sin(angle * 4 + frameCount * rippleSpeed) * rippleAmp;
     vertex(baseX, baseY + ripple);
   }
   endShape(CLOSE);
   pop();
 }
 
 function drawCigarette(c) {
   c.emberX = c.x + cos(c.angle) * 0;
   c.emberY = c.y + sin(c.angle) * 0;
 
   push();
   translate(c.x, c.y);
   rotate(c.angle);
 
   noStroke();
   fill(245);
   rect(0, -c.thick / 2, c.len, c.thick, 4);
 
   fill(210, 150, 80);
   rect(c.len * 0.8, -c.thick / 2, c.len * 0.2, c.thick, 2);
 
   const emberSize = c.thick * 0.72;
   fill(255, random(80, 140), 0, random(190, 255));
   ellipse(0, 0, emberSize);
 
   fill(255, 120, 0, 60);
   ellipse(0, 0, emberSize * 1.8);
 
   pop();
 }
 
 function emitCigSmoke() {
   const near = dist(mouseX, mouseY, cig.emberX, cig.emberY) < 40;
   const baseRate = (mood === "calm") ? 7 : 4;
   const extra = near ? 0.5 : 0;
 
   cigEmitTimer++;
   if (cigEmitTimer % int(max(1, baseRate - extra)) === 0) {
     const bursts = (mood === "furious") ? 2 : 1;
     for (let i = 0; i < bursts; i++) {
       cigSmoke.push(new CigSmoke(cig.emberX, cig.emberY));
     }
   }
 }
 
 function updateDrawCigSmoke() {
   for (let i = cigSmoke.length - 1; i >= 0; i--) {
     cigSmoke[i].update();
     cigSmoke[i].display();
     if (cigSmoke[i].alpha <= 0) cigSmoke.splice(i, 1);
   }
 }
 
 class CigSmoke {
   constructor(x, y) {
     this.x = x + random(-2, 2);
     this.y = y + random(-2, 2);
     this.alpha = 180;
     this.r = random(8, 16);
     this.t = random(1000);
     this.vy = random(-0.7, -0.3);
   }
   update() {
     let n = noise(this.t);
     let vx = map(n, 0, 1, -0.4, 0.4);
     this.x += vx;
     this.y += this.vy;
     this.t += 0.01;
     this.alpha -= 0.9;
     this.r += 0.08;
   }
   display() {
     noStroke();
     fill(230, this.alpha);
     ellipse(this.x, this.y, this.r);
   }
 }
 
 /* --------------------- FX + HUD helpers ---------------------- */
 
 function drawGrain(alphaVal, count) {
   push();
   stroke(255, alphaVal);
   for (let i = 0; i < count; i++) {
     point(random(width), random(height));
   }
   pop();
 }
 
 function drawHint(msg, x, y) {
   push();
   textAlign(LEFT, BOTTOM);
   textSize(12);
   let pad = 6;
   let tw = textWidth(msg);
   fill(0, 140);
   rect(x - pad - 2, y - 14 - pad, tw + pad * 2, 18 + pad, 6);
   fill(255);
   text(msg, x, y - 4);
   pop();
 }
 